#!/sbin/sh
 
sync;
/sbin/umount /system
/sbin/umount /cache

# format ext4 with alignment
/tmp/superwipe/mkfs.ext4 -t ext4 -b 4096 -m 0 -F -L userdata /dev/block/mmcblk0p24
/tmp/superwipe/tune2fs -o journal_data_ordered /dev/block/mmcblk0p24
/tmp/superwipe/tune2fs -E hash_alg=tea /dev/block/mmcblk0p24
/tmp/superwipe/tune2fs -e continue /dev/block/mmcblk0p24
/tmp/superwipe/e2fsck /dev/block/mmcblk0p24
/tmp/superwipe/e2fsck -yf /dev/block/mmcblk0p24

/tmp/superwipe/mkfs.ext4 -t ext4 -b 4096 -m 0 -F -L userdata /dev/block/mmcblk0p26
/tmp/superwipe/tune2fs -o journal_data_ordered /dev/block/mmcblk0p26
/tmp/superwipe/tune2fs -E hash_alg=tea /dev/block/mmcblk0p26
/tmp/superwipe/tune2fs -e continue /dev/block/mmcblk0p26
/tmp/superwipe/e2fsck /dev/block/mmcblk0p26
/tmp/superwipe/e2fsck -yf /dev/block/mmcblk0p26

sync;
rm -r /tmp/superwipe;
sync;
